import { TeamsActivityHandler, CardFactory, TurnContext, AppBasedLinkQuery } from "botbuilder";
import { ResponseType, Client } from "@microsoft/microsoft-graph-client";
import { TokenCredentialAuthenticationProvider } from "@microsoft/microsoft-graph-client/authProviders/azureTokenCredentials";
import {
  MessageExtensionTokenResponse,
  handleMessageExtensionQueryWithSSO,
  OnBehalfOfCredentialAuthConfig,
  OnBehalfOfUserCredential,
} from "@microsoft/teamsfx";
import "isomorphic-fetch";
import config from "./config";

const oboAuthConfig: OnBehalfOfCredentialAuthConfig = {
  authorityHost: config.authorityHost,
  clientId: config.clientId,
  tenantId: config.tenantId,
  clientSecret: config.clientSecret,
};

const initialLoginEndpoint = `https://${config.botDomain}/auth-start.html`;

export class TeamsBot extends TeamsActivityHandler {
  constructor() {
    super();
  }

  // This function handles a Teams messaging extension query.
  public async handleTeamsMessagingExtensionQuery(
    context: TurnContext, // The context of the Teams activity.
    query: any // The query from the Teams client.
  ): Promise<any> {
    // Use the SSO authentication method to handle the query.
    return await handleMessageExtensionQueryWithSSO(
      context,
      oboAuthConfig, // The configuration for on-behalf-of authentication.
      initialLoginEndpoint, // The endpoint for initial login.
      ["User.Read.All", "User.Read"], // The scopes required for the Graph API calls.
      async (token: MessageExtensionTokenResponse) => { // The callback to run after authentication.
        // Create a credential object with the SSO token and the authentication configuration.
        const credential = new OnBehalfOfUserCredential(
          token.ssoToken,
          oboAuthConfig
        );
        // Initialize an empty array to hold the attachments.
        const attachments = [];
        // Create an authentication provider with the credential and the required scopes.
        const authProvider = new TokenCredentialAuthenticationProvider(
          credential,
          {
            scopes: ["User.Read"],
          }
        );
        // Initialize a Graph client with the authentication provider.
        const graphClient = Client.initWithMiddleware({
          authProvider: authProvider,
        });

        // Check if this is the initial run of the query.
        if (query.parameters[0] && query.parameters[0].name === "initialRun") {
          
          // If it is, get the profile of the currently signed-in user.
          const profile = await graphClient.api("/me").get();

          // Add the user's profile as an attachment.
          attachments.push(this.createUserAttachment(profile));
        } else {
          // If this is not the initial run, we need to search for users.

          // Initialize a new authentication provider with the necessary scopes to read all users.
          const authProvider = new TokenCredentialAuthenticationProvider(
            credential,
            {
              scopes: ["User.Read.All"],
            }
          );
          // Initialize a new Graph client with the new authentication provider.
          const graphClient = Client.initWithMiddleware({
            authProvider: authProvider,
          });

          // Get the search context from the query parameters.


          // Use the Graph API to search for users by their display name.
          let users = await graphClient
            .api(`PATH`)
            .header("ConsistencyLevel", "eventual")
            .orderby("displayName")
            .get();

          // For each user found, get their details and add them to the attachments.
          for (const user of users.value) {
            attachments.push(this.createUserAttachment(user));
          }
        }
        // Return the attachments as a result to the Teams client.
        return {
          composeExtension: {
            type: "result",
            attachmentLayout: "list",
            attachments: attachments,
          },
        };
      }
    );
  }

  createUserAttachment(user) {
    return CardFactory.thumbnailCard(
      user.displayName,
      `Email: ${user.mail ? user.mail : "Email not available"}\nPhone: ${user.businessPhones[0] ? user.businessPhones[0] : "Phone not available"}`
    );
  }
}
